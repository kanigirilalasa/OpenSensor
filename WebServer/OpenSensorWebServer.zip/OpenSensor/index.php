﻿<script type="text/javascript">
function alertFunc() {
	alert("Hello!");
}

function MQ2(){
	$result = $conn->query("SELECT time, field, value FROM datatable ORDER BY time DESC LIMIT 1");
	// if($result->num_rows > 0){
	// 	while($row = $result->fetch_assoc()){
	// 		echo $row['time']." ".$row['field']." ".$row['value'].'<br>';
	// 	}
	// }
	// $row = $result->num_rows - 1;
	return $result;
}
</script>

<!DOCTYPE html>
<html>
<head>
	<title>He Thong Hien Thi Du Lieu Cam Bien</title>
	<link rel="stylesheet" href="css/css/bootstrap.min.css">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<style type="text/css">
		#title{
			/*height: 5%;*/
			text-align:center;
		}
		.container{
			/*height: 92%;*/
		}
		#row1{
			/*height:50%;*/
		}
		#row2{
			/*height:50%;*/
		}
		#mq2{
			/*height:90%; */
			border: 2px solid; 
			border-radius: 10px;
		}
		#mq135{
			/*height:90%;*/
			border: 2px solid; 
			border-radius: 10px;
		}
		#mg811{
			/*height:90%; */
			border: 2px solid; 
			border-radius: 10px;
		}
		#gp2y10{
			/*height:90%; */
			border: 2px solid; 
			border-radius: 10px;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="row">
			<h1 id="title">Hệ Thống Hiển Thị Dữ Liệu Cảm Biến</h1>
			<hr>
		</div>

	<div class="container">
		<!-- <div style="height: 20%"></div> -->
		<div class="row" id="row1">
			<div class="col-md-5" id="mq2">
			  	<h4>Cảm Biến MQ2</h4>
			  	<table class="table table-hover">
			  		<tr>
			  			<th>Thời điểm</th>
			  			<th>Nồng độ</th>
			  			<th>Giá trị</th>
			  			<th>Đơn vị đo</th>
			  		</tr>
				  <tr id="MQ2_LGP">
				  </tr>
				</table>
				</div>

			<div class="col-md-2"></div>	

			<div class="col-md-5" id="mq135">	
				<h4>Cảm Biến MQ135</h4>
			  	<table class="table table-hover">
			  		<tr>
			  			<th>Thời điểm</th>
			  			<th>Nồng độ</th>
			  			<th>Giá trị</th>
			  			<th>Đơn vị đo</th>
			  		</tr>
				  <tr id="MQ135_SMOKE">				    
				  </tr>
			  	</table>
			  </div>
		</div>
		<br>
		<div class="row" id="row2">
			  <div class="col-md-5" id="mg811">
			  <h4>Cảm Biến MG811</h4>
			  	<table class="table table-hover">
			  		<tr>
			  			<th>Thời điểm</th>
			  			<th>Nồng độ</th>
			  			<th>Giá trị</th>
			  			<th>Đơn vị đo</th>
			  		</tr>
				  <tr id="MG811_CO2">
				  </tr>
				  </table>
		  	  </div>

		  	  <div class="col-md-2"></div>	

		  	  <div class="col-md-5" id="gp2y10">	
				<h4>Cảm Biến GP2Y10</h4>
			  	<table class="table table-hover">
			  		<tr>
			  			<th>Thời điểm</th>
			  			<th>Nồng độ</th>
			  			<th>Giá trị</th>
			  			<th>Đơn vị đo</th>
			  		</tr>
				  <tr id="GP2Y10_DUST">
				  </tr>
			  	</table>
			  </div>
		</div>	
</div>
</body>
</html>

<script type="text/javascript" src="js/jquery-1.12.2.min.js"></script>

<script type="text/javascript">
			    
$(document).ready(function(){
	setInterval(function(){
		$('#MQ2_LGP').load('mq2-lpg.php');
		$('#MQ135_SMOKE').load('mq135-smoke.php');
		$('#MG811_CO2').load('mg811-co2.php');
		$('#GP2Y10_DUST').load('gp2y10-dust.php')
	}, 100);
});


</script>

<!-- <div id="show"></div>
		
<script type="text/javascript">
$(document).ready(function(){
	setInterval(function(){
		$('#show').load('connection.php')
	}, 3000);
});
</script> -->