<?php
	include('connection.php');

	$result = $conn->query("SELECT TIME, GAS, VALUE FROM sensorvalue WHERE SENSORMODEL = 'MG811' ORDER BY TIME DESC LIMIT 1");
	if($result->num_rows > 0){
		while($row = $result->fetch_assoc()){
			echo "<td>".$row['TIME']."</td>".
				    "<td>".$row['GAS']."</td>".
				    "<td>".$row['VALUE']."</td>".
				    "<td>ppm</td>";
		}
	}
?>